package com.pofist;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.preference.EditTextPreference;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class UpdateActivity extends AppCompatActivity implements LocationListener {
    TextView textView11;
    TextView textView14,textView13;
    Button button12,button13,button19;
    LocationManager locationManager;
    int code=123;
    SQLiteDatabase db;
    String x,x2;
    EditText editText8,editText9;
    String[] ListItems;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);
        button12=findViewById(R.id.button12);
        button13=findViewById(R.id.button13);
        button19=findViewById(R.id.button19);
        textView14 = findViewById(R.id.textView14);
        textView13 = findViewById(R.id.textView13);
        textView11 = findViewById(R.id.textView11);
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        editText8=findViewById(R.id.editTextTextPersonName8);
        editText9=findViewById(R.id.editTextTextPersonName9);
    }
    public void close(View view) {
        finish();
        System.exit(0);
    }
    public void Select(View view)
    {
        {
            ListItems=new String[]{"Historical Site","University","Cafe- Restaurant","Stadium","Nature","House","Other.."};
            AlertDialog.Builder builder= new AlertDialog.Builder(UpdateActivity.this);
            builder.setTitle("Choose a category");
            builder.setSingleChoiceItems(ListItems, -1, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int i) {
                    button19.setText(ListItems[i]);
                    dialog.dismiss();
                }
            });
            builder.setNeutralButton("Back", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {

                }
            });
            AlertDialog dialog=builder.create();
            dialog.show();
        }
    }
    public void Update(View view) {

        Long tsLong = System.currentTimeMillis()/1000;
        String ts = tsLong.toString();
        ContentValues values = new ContentValues();
        values.put("name", editText8.getText().toString());
        values.put("info", editText9.getText().toString());
        values.put("category", button19.getText().toString());
        values.put("timestamp",ts);
        db.update("POI4",values,"la=? and lo=?",new String[]{x,x2});
        db.close();
        showAlertDialogButtonClicked("UPDATE COMPLETE!");
        button13.setVisibility(View.INVISIBLE);

    }
    public void Search(View view)
    {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.ACCESS_FINE_LOCATION},123);
            return;
        }
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 100, this);
        showAlertDialogButtonClicked("This process will take some seconds");
    }
    public void showAlertDialogButtonClicked(String s) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Message");
        builder.setMessage(s);
        builder.setPositiveButton("OK", null);
        AlertDialog dialog = builder.create();
        dialog.show();
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(code, permissions, grantResults);
    }

    @Override
    public void onLocationChanged(@NonNull Location location)
    {
        boolean f=true;
        textView11.setText(String.valueOf(location.getLatitude())+","+String.valueOf(location.getLongitude()));
        x=String.valueOf(location.getLatitude());
        x2=String.valueOf(location.getLongitude());
        x = x.substring (0,6);
        x2 = x2.substring (0,6);
        db=openOrCreateDatabase("SQ1.db",MODE_PRIVATE,null);
        Cursor cursor = db.rawQuery("SELECT la, lo,name,info,category FROM POI4 WHERE la = ? AND lo = ?", new String[]{x,x2});
        while(cursor.moveToNext())
        {
            f=false;
            textView13.setVisibility(View.VISIBLE);
            textView14.setVisibility(View.VISIBLE);
            editText9.setVisibility(View.VISIBLE);
            editText8.setVisibility(View.VISIBLE);
            editText8.setText(cursor.getString(2));
            editText9.setText(cursor.getString(3));
            button13.setVisibility(View.VISIBLE);
            button19.setText(cursor.getString(4));
            button19.setVisibility(View.VISIBLE);
        }
        if(f){ showAlertDialogButtonClicked("There are no POIs with these coordinates");}
        locationManager.removeUpdates(this);

    }
}