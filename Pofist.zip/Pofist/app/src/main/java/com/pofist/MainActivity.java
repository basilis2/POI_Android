package com.pofist;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button button;
    Button button2;
    Button button3;
    Button button4;
    SQLiteDatabase sq;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sq=openOrCreateDatabase("SQ1.db",MODE_PRIVATE,null);
        sq.execSQL("Create table if not exists POI4("+
                "la REAL NOT NULL," +
                "lo REAL NOT NULL," +
                "name TEXT ," +
                "category TEXT ," +
                "info TEXT ," +
                "timestamp TEXT ," +
                "latitude TEXT ," +
                "longitude TEXT ," +
                "PRIMARY KEY (la,lo))");
        sq.execSQL("Insert or ignore into POI4 Values(37.970,23.726,'Acropolis','Historical Site','wonderfull place','1320917972','37.970833','23.726110')");
        button = (Button) findViewById(R.id.button);//GIA NA ANOIKSV THN SELIDA EISAGVGHS
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, InsertActivity.class));
            }
        });
        button2 = (Button) findViewById(R.id.button2);//GIA NA ANOIKSV THN SELIDA Delete
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, DeleteActivity.class));
            }
        });
        button3 = (Button) findViewById(R.id.button4);//GIA NA ANOIKSV THN SELIDA Search
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, SearchActivity.class));
            }
        });
        button4 = (Button) findViewById(R.id.button3);//GIA NA ANOIKSV THN SELIDA Update
        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, UpdateActivity.class));
            }
        });
    }
    public void close(View view) {
        finish();
        System.exit(0);
    }
    public void showAlertDialogButtonClicked(String s) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Message");
        builder.setMessage(s);
        builder.setPositiveButton("OK", null);
        AlertDialog dialog = builder.create();
        dialog.show();
    }
    public void View(View view)
    {
        Cursor cursor=sq.rawQuery("SELECT * FROM POI4",null);
        StringBuilder builder=new StringBuilder();
        int count=0;
        while(cursor.moveToNext())
        {
            count++;
            builder.append(count).append("\n");
            builder.append("NAME"+" : ").append(cursor.getString(2)).append("\n");
            builder.append("CATEGORY"+" : ").append(cursor.getString(3)).append("\n");
            builder.append("INFO"+" : ").append(cursor.getString(4)).append("\n");
            builder.append("TIMESTAMP"+" : ").append(cursor.getString(5)).append("\n");
            builder.append("Latitude"+" : ").append(cursor.getDouble(6)).append("\n");
            builder.append("Longitude"+" : ").append(cursor.getDouble(7)).append("\n");

        }
        showAlertDialogButtonClicked(builder.toString());
    }
}