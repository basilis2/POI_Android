package com.pofist;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.app.LauncherActivity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.location.LocationRequest;
import android.os.Bundle;
import android.preference.EditTextPreference;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class InsertActivity extends AppCompatActivity implements LocationListener {
    Button button7;
    Button button9;
    TextView textView4;
    TextView textView5;
    LocationManager locationManager;
    String[] ListItems;
    TextView text;
    int code=123;
    SQLiteDatabase db;
    EditText editText;
    EditText editText2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        setContentView(R.layout.activity_insert);
        editText=findViewById(R.id.editTextTextPersonName);
        editText2=findViewById(R.id.editTextTextPersonName2);
        button7=(Button) findViewById(R.id.button7);
        button9=(Button) findViewById(R.id.button9);
        textView4 = findViewById(R.id.textView4);
        textView5 = findViewById(R.id.textView5);
        text = findViewById(R.id.textView18);
    }
    public void close(View view) {
        finish();
        System.exit(0);
    }
    public void showAlertDialogButtonClicked(String s) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Message");
        builder.setMessage(s);
        builder.setPositiveButton("OK", null);
        AlertDialog dialog = builder.create();
        dialog.show();
    }
    public void get(View view){
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.ACCESS_FINE_LOCATION},123);
            return;
        }
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 100, this);
        showAlertDialogButtonClicked("This process will take some seconds");
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(code, permissions, grantResults);
    }

    @Override
    public void onLocationChanged(@NonNull Location location) {
        Boolean f=false;
        textView4.setText(String.valueOf(location.getLatitude()));
        textView5.setText(String.valueOf(location.getLongitude()));
        db=openOrCreateDatabase("SQ1.db",MODE_PRIVATE,null);
        Cursor cursor = db.rawQuery("SELECT la, lo,name,info,category FROM POI4 WHERE la = ? AND lo = ?", new String[]{String.valueOf(location.getLatitude()).substring(0,6),String.valueOf(location.getLongitude()).substring(0,6)});
        while(cursor.moveToNext()) {f=true;}
        db.close();
        if(f){ showAlertDialogButtonClicked("YOU ΗAD COME TO THIS AREA AGAIN. GO TO SEARCH POI TO SEE WHERE ARE YOU");button9.setVisibility(View.INVISIBLE);}
        else{button9.setVisibility(View.VISIBLE);}
        locationManager.removeUpdates(this);
    }
    public void Insert(View view)
    {
        String la=textView4.getText().toString();
        String lo=textView5.getText().toString();
        String name=editText.getText().toString();
        String category=text.getText().toString();
        String info=editText2.getText().toString();
        Long tsLong = System.currentTimeMillis()/1000;
        String ts = tsLong.toString();
        db=openOrCreateDatabase("SQ1.db",MODE_PRIVATE,null);
        db.execSQL("Insert into POI4 Values(?,?,?,?,?,?,?,?)",new String[]{la.substring(0,6),lo.substring(0,6),name,category,info,ts,la,lo});
        showAlertDialogButtonClicked("Insert Complete!!!!!");
        button9.setVisibility(View.INVISIBLE);
    }
    public void Category(View view)
    {
        ListItems=new String[]{"Historical Site","University","Cafe- Restaurant","Stadium","Nature","House","Other.."};
        AlertDialog.Builder builder= new AlertDialog.Builder(InsertActivity.this);
        builder.setTitle("Choose a category");
        builder.setSingleChoiceItems(ListItems, -1, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int i) {
                text.setText(ListItems[i]);
                dialog.dismiss();
            }
        });
        builder.setNeutralButton("Back", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        AlertDialog dialog=builder.create();
        dialog.show();
    }
}