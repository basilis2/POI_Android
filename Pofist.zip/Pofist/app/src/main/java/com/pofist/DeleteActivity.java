package com.pofist;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;



public class DeleteActivity extends AppCompatActivity implements LocationListener {
    Button button11,button10,button18;
    TextView textview19;
    TextView textview20;
    TextView textview21;
    Double value;
    String x,x2,s2,s3;
    LocationManager locationManager;
    int code=123;
    SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete);
        button11=findViewById(R.id.button11);
        button10=findViewById(R.id.button10);
        button18=findViewById(R.id.button18);
        textview19=findViewById(R.id.textView19);
        textview20=findViewById(R.id.textView20);
        textview21=findViewById(R.id.textView21);
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
    }
    public void close(View view) {
        finish();
        System.exit(0);
    }
    public void showAlertDialogButtonClicked(String s) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Message");
        builder.setMessage(s);
        builder.setPositiveButton("OK", null);
        AlertDialog dialog = builder.create();
        dialog.show();
    }
    public void Delete(View view)
    {
        db=openOrCreateDatabase("SQ1.db",MODE_PRIVATE,null);
        db.delete("POI4","la =? and lo=?",new String[]{s2,s3} );
        db.close();
        showAlertDialogButtonClicked("DELETE COMPLETE!");
        button11.setVisibility(View.INVISIBLE);
    }
    public void Search(View view)
    {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.ACCESS_FINE_LOCATION},123);
            return;
        }
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 100, this);
        showAlertDialogButtonClicked("This process will take some seconds");
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(code, permissions, grantResults);
    }

    @Override
    public void onLocationChanged(@NonNull Location location) {
        boolean f=true;
        textview19.setText(String.valueOf(location.getLatitude())+","+String.valueOf(location.getLongitude()));
        x=String.valueOf(location.getLatitude());
        x2=String.valueOf(location.getLongitude());
        s2 = x.substring (0,6);
        s3 = x2.substring (0,6);
        db=openOrCreateDatabase("SQ1.db",MODE_PRIVATE,null);
        Cursor cursor = db.rawQuery("SELECT la, lo,name,category FROM POI4 WHERE la = ? AND lo = ?", new String[]{s2,s3});
        while(cursor.moveToNext())
        {
            f=false;
            textview20.setText(cursor.getString(2));
            textview21.setText(cursor.getString(3));
            button11.setVisibility(View.VISIBLE);
        }
        if(f){ showAlertDialogButtonClicked("There are no POIs with these coordinates");}
        locationManager.removeUpdates(this);

    }
}