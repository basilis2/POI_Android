package com.pofist;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class SearchActivity extends AppCompatActivity implements LocationListener {
    TextView textview16;
    TextView textview17;
    TextView textview22;
    Button button16;
    int code=123;
    String x,x2;
    SQLiteDatabase db;
    LocationManager locationManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        textview16 = (TextView)findViewById(R.id.textView16);
        textview17 = (TextView)findViewById(R.id.textView17);
        textview22 = (TextView)findViewById(R.id.textView22);
        button16=findViewById(R.id.button16);
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
    }
    public void close(View view) {
        finish();
        System.exit(0);
    }
    public void showAlertDialogButtonClicked(String s) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Message");
        builder.setMessage(s);
        builder.setPositiveButton("OK", null);
        AlertDialog dialog = builder.create();
        dialog.show();
    }
    public void Search(View view)
    {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.ACCESS_FINE_LOCATION},123);
            return;
        }
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 100, this);
        showAlertDialogButtonClicked("This process will take some seconds");
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(code, permissions, grantResults);
    }

    @Override
    public void onLocationChanged(@NonNull Location location)
    {
        boolean f=true;
        x=String.valueOf(location.getLatitude());
        x2=String.valueOf(location.getLongitude());
        x = x.substring (0,6);
        x2 = x2.substring (0,6);
        db=openOrCreateDatabase("SQ1.db",MODE_PRIVATE,null);
        Cursor cursor = db.rawQuery("SELECT la, lo,name,info,category FROM POI4 WHERE la = ? AND lo = ?", new String[]{x,x2});
        while(cursor.moveToNext())
        {
            f=false;
            showAlertDialogButtonClicked("YOU ARE HERE");
            textview16.setText(cursor.getString(2));
            textview17.setText(cursor.getString(4));
            textview22.setText(cursor.getString(3));

        }
        db.close();
        if(f){ showAlertDialogButtonClicked("There are no saved POIS in this area");}
        locationManager.removeUpdates(this);
    }
}